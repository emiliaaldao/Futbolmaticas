import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import MathFutbolApp from "./MathFutbolApp";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <MathFutbolApp />
  </React.StrictMode>
);