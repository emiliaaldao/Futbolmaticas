import React, { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const operations = ["+", "-", "×", "÷"];

function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function generateQuestion() {
  const op = operations[getRandomInt(0, operations.length - 1)];
  let a = getRandomInt(1, 10);
  let b = getRandomInt(1, 10);
  if (op === "÷") {
    a = a * b; // ensure divisible
  }
  return { a, b, op };
}

function calculateAnswer(a, b, op) {
  switch (op) {
    case "+": return a + b;
    case "-": return a - b;
    case "×": return a * b;
    case "÷": return a / b;
    default: return 0;
  }
}

export default function MathFutbolApp() {
  const [question, setQuestion] = useState(generateQuestion());
  const [userAnswer, setUserAnswer] = useState("");
  const [feedback, setFeedback] = useState("");
  const [streak, setStreak] = useState(0);
  const [trophies, setTrophies] = useState(0);
  const [correction, setCorrection] = useState("");

  const handleSubmit = () => {
    const correct = calculateAnswer(question.a, question.b, question.op);
    if (parseFloat(userAnswer) === correct) {
      setFeedback("¡Golazo! ¡Respuesta correcta!");
      setCorrection("");
      setStreak(prev => {
        const newStreak = prev + 1;
        if (newStreak % 5 === 0) {
          setTrophies(t => t + 1);
        }
        return newStreak;
      });
    } else {
      setFeedback("¡Uy, casi! Intenta otra vez.");
      setCorrection(`La respuesta correcta era ${correct}`);
      setStreak(0);
    }
    setQuestion(generateQuestion());
    setUserAnswer("");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-100 to-green-100 flex flex-col items-center justify-center p-4 text-center">
      <h1 className="text-3xl font-bold text-blue-800 mb-4">Desafío Albiceleste Matemático</h1>
      <Card className="w-full max-w-md bg-white shadow-xl rounded-2xl border-blue-300 border-4">
        <CardContent className="p-6">
          <div className="text-xl mb-4">
            ¿Cuánto es {question.a} {question.op} {question.b}?
          </div>
          <Input
            type="number"
            value={userAnswer}
            onChange={(e) => setUserAnswer(e.target.value)}
            className="mb-4 text-center text-lg"
          />
          <Button onClick={handleSubmit} className="w-full bg-blue-600 hover:bg-blue-700 text-white text-lg">
            Responder
          </Button>
          <div className="mt-4 text-green-700 font-semibold">{feedback}</div>
          {correction && <div className="mt-2 text-red-500">{correction}</div>}
          <div className="mt-4 text-sm text-gray-700">
            Racha actual: {streak} | Copas ganadas: 🏆 {trophies}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}